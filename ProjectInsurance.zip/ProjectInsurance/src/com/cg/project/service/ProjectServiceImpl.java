package com.cg.project.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.project.dao.CRSDao;
import com.cg.project.dao.ProjectDaoImpl;
import com.cg.project.entity.Presentation;
import com.cg.project.exception.ProjectException;

public class ProjectServiceImpl implements ProjectService {
	CRSDao projectDao = new ProjectDaoImpl();



/*	private boolean checkpolicyNumber(int policyNumber) {
		String policynumberRegEx = "[0-9]{10}$";
		return Pattern.matches(policynumberRegEx, String.valueOf(policyNumber));
	}
	private boolean checkaccidentZip(int accidentZip) {
		String accidentzipRegEx = "[0-9]{5}$";
		return Pattern.matches(accidentzipRegEx, String.valueOf(accidentZip));
	}

	private boolean checkaccidentState(String accidentState) {
		String accidentstateRegEx = "[A-Z]{1}[a-zA-Z]{3,15}$";
		return Pattern.matches(accidentstateRegEx, String.valueOf(accidentState));
	}

	private boolean checkaccidentCity(String accidentCity) {
		String accidentcityRegEx = "[A-Z]{1}[a-zA-Z]{2,15}$";
		return Pattern.matches(accidentcityRegEx, String.valueOf(accidentCity));
	}

	private boolean checkAccidentLocationStreet(String accidentLocationStreet) {
	}

	public boolean CheckclaimReason(String claimReason) {
		
	}
*/
	@Override
	public int addCustomerDetails(Presentation presentation) throws ProjectException {
		// TODO Auto-generated method stub
		return projectDao.addCustomerDetails(presentation);
	}



	@Override
	public boolean CheckClaimReason(String claimReason) {
		String claimreasonRegEx = "[A-Z]{1}[a-zA-Z]{4,30}$";
		boolean input=Pattern.matches(claimreasonRegEx, String.valueOf(claimReason));
		return input;
		}



	@Override
	public boolean CheckAccidentLocationStreet(String accidentLocationStreet) {
		String accidentlocationstreetRegEx = "[A-Z]{1}[a-zA-Z0-9\\s]{4,30}$";
		return Pattern.matches(accidentlocationstreetRegEx, String.valueOf(accidentLocationStreet));
	}



	@Override
	public boolean CheckAccidentCity(String accidentCity) {
		String accidentcityRegEx = "[A-Z]{1}[a-zA-Z\\s]{2,15}$";
		return Pattern.matches(accidentcityRegEx, String.valueOf(accidentCity));
	}



	@Override
	public boolean CheckAccidentState(String accidentState) {
		String accidentstateRegEx = "[A-Z]{1}[a-zA-Z\\s]{3,15}$";
		return Pattern.matches(accidentstateRegEx, String.valueOf(accidentState));
	}



	@Override
	public boolean CheckAccidentZip(long accidentZip) {
		String accidentzipRegEx = "[0-9]{5}$";
		return Pattern.matches(accidentzipRegEx, String.valueOf(accidentZip));
	}



	@Override
	public boolean CheckPolicyNumber(long policyNumber) {
		String policynumberRegEx = "[0-9]{10}$";
		return Pattern.matches(policynumberRegEx, String.valueOf(policyNumber));
		
	}



	@Override
	public List<Presentation> claimData(String userName) throws ProjectException {
		// TODO Auto-generated method stub
		return projectDao.claimData(userName);
	}
		
}
