package com.cg.project.service;

import java.util.List;

import com.cg.project.entity.Presentation;
import com.cg.project.exception.ProjectException;

public interface ProjectService {

	int addCustomerDetails(Presentation presentation) throws ProjectException;

	boolean CheckClaimReason(String claimReason);

	boolean CheckAccidentLocationStreet(String accidentLocationStreet);

	boolean CheckAccidentCity(String accidentCity);

	boolean CheckAccidentState(String accidentState);

	boolean CheckAccidentZip(long accidentZip);

	boolean CheckPolicyNumber(long policyNumber);

	List<Presentation> claimData(String userName) throws ProjectException;


}
