package com.cg.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.project.entity.Presentation;
import com.cg.project.exception.ProjectException;
import com.cg.project.jdbc.JDBCUtility;

public class ProjectDaoImpl implements CRSDao {
	Connection connection = null;

	PreparedStatement statement = null;
	ResultSet resultSet = null;
	static Logger logger = Logger.getLogger(ProjectDaoImpl.class);

	@Override
	public int addCustomerDetails(Presentation presentation) throws ProjectException {
		logger.info("in add Customer method");
		/**
		 * method : addCustomerDetails 
		 * argument : it's taking model object as an argument 
		 * return type : this method return the generated id to the user 
		 * Author : Capgemini 
		 * Date : 04 - Feb - 2019
		 * 
		 **/

		connection = JDBCUtility.getConnection();
		logger.info("connection object created");

		/* String str=String.valueOf(mobile.getMobileNumber()); */
		int generatedId = 0;
	
		try {

			statement = connection.prepareStatement(QueryMapper.insertCustomerDetails);
			logger.debug("statement object created");
			/*System.out.println("statement object created");*/
			statement.setString(1, presentation.getAgentClaimReason());
			statement.setString(2, presentation.getAgentAccidentLocationStreet());
			statement.setString(3, presentation.getAgentAccidentCity());
			statement.setString(4, presentation.getAgentAccidentState());
			statement.setLong(5, presentation.getAgentAccidentZip());
			statement.setString(6, presentation.getAgentClaimType());
			statement.setLong(7, presentation.getAgentPolicyNumber());
			/*System.out.println("SETTED");*/
			generatedId = statement.executeUpdate();
			/*System.out.println("eXECUTED");*/
			logger.info("execute update called");

		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			throw new ProjectException("problem occured while creating the statement object");
		}
		return generatedId;
	}

	@Override
	public List<Presentation> claimData(String userName) throws ProjectException {
		connection = JDBCUtility.getConnection();
		List<Presentation> list = new ArrayList<>();
		try {
			statement = connection.prepareStatement(QueryMapper.viewClaimHistory);
			statement.setString(1, userName);
			logger.info("connection created");
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Long agentClaimNumber = resultSet.getLong(1);
				String agentClaimReason = resultSet.getString(2);
				String agentAccidentLocationStreet = resultSet.getString(3);
				String agentAccidentCity = resultSet.getString(4);
				String agentAccidentState = resultSet.getString(5);
				Long agentAccidentZip = resultSet.getLong(6);
				String agentClaimType = resultSet.getString(7);
				Long agentPolicyNumber = resultSet.getLong(8);
				Presentation presentation = new Presentation();
				presentation.setAgentClaimNumber(agentClaimNumber);
				presentation.setAgentClaimReason(agentClaimReason);
				presentation.setAgentAccidentLocationStreet(agentAccidentLocationStreet);
				presentation.setAgentAccidentCity(agentAccidentCity);
				presentation.setAgentAccidentState(agentAccidentState);
				presentation.setAgentAccidentZip(agentAccidentZip);
				presentation.setAgentClaimType(agentClaimType);
				presentation.setAgentPolicyNumber(agentPolicyNumber);
				
				list.add(presentation);
				logger.info("Claim History viewed successfully");
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("statement problem");
			throw new ProjectException("statement problem occured while creating statement object");

		}
	/*	try {
			statement = connection.prepareStatement(QueryMapper.viewClaimHistory1);
			logger.info("connection created");
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Long customerAccountNumber = resultSet.getLong("ACCOUNT_NUMBER");
				String userName = resultSet.getString("USERNAME");
				Presentation presentation= new Presentation();
				presentation.setCustomerAccountNumber(customerAccountNumber);
				presentation.setUserName(userName);
				list.add(presentation);
				logger.info("Claim History viewed successfully");
			}
		} catch (SQLException e) {
			logger.error("statement problem");
			throw new ProjectException("statement problem occured while creating statement object");

		}*/


		return list;
	}

}
