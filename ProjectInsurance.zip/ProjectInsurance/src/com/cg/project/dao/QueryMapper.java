package com.cg.project.dao;

public interface QueryMapper {

	public static final String insertCustomerDetails = "insert into claim values(claim_number_seq.nextval,?,?,?,?,?,?,?)";
	/*public static String viewClaimHistory = "Select CLAIM_TYPE,POLICY_NUMBER from claim";
	public static String viewClaimHistory2 = "Select POLICY_NUMBER,ACCOUNT_NUMBER from policy";*/
	public static String viewClaimHistory = "Select  * from claim where policy_number=(select policy_number from policy where account_number=(select account_number from accounts where username=?))";
}
