package com.cg.project.dao;

import java.util.List;

import com.cg.project.entity.Presentation;
import com.cg.project.exception.ProjectException;

public interface CRSDao {

	int addCustomerDetails(Presentation presentation) throws ProjectException;

	List<Presentation> claimData(String userName) throws ProjectException;

}
